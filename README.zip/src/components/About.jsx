import React from "react";
import Tilt from "react-tilt";
import { motion } from "framer-motion";
import { styles } from "../styles";
import { SectionWrapper } from "../hoc";
import { fadeIn, textVariant } from "../utils/motion";

// Importing images
import webIcon from "../assets/web.png";
import backendIcon from "../assets/backend.png";
import mobileIcon from "../assets/mobile.png";
import fullstackIcon from "../assets/creator.png";

const updatedServices = [
  { title: "Frontend Developer", icon: webIcon },
  { title: "Backend Developer", icon: backendIcon },
  { title: "Web Developer", icon: webIcon },
  { title: "Full Stack Developer", icon: fullstackIcon },
];

const ServiceCard = ({ index, title, icon }) => (
  <Tilt className="xs:w-[250px] w-full">
    <motion.div
      variants={fadeIn("right", "spring", index * 0.5, 0.75)}
      className="w-full green-pink-gradient p-[1px] rounded-[20px] shadow-card"
    >
      <div className="bg-tertiary rounded-[20px] py-5 px-12 min-h-[280px] flex justify-evenly items-center flex-col">
        <img src={icon} alt={title} className="w-16 h-16 object-contain" />
        <h3 className="text-white text-[20px] font-bold text-center">
          {title}
        </h3>
      </div>
    </motion.div>
  </Tilt>
);

const About = () => {
  return (
    <>
      <motion.div variants={textVariant()}>
        <p className={styles.sectionSubText}>Introduction</p>
        <h2 className={styles.sectionHeadText}>Overview.</h2>
      </motion.div>

      <motion.p
        variants={fadeIn("", "", 0.1, 1)}
        className="mt-4 text-secondary text-[17px] max-w-3xl leading-[30px]"
      >
        "I'm a Full Stack Developer skilled in building modern, scalable, and
        efficient web applications. Let's create something amazing together!"
      </motion.p>

      <div className="mt-20 flex flex-wrap gap-10">
        {updatedServices.map((service, index) => (
          <ServiceCard key={service.title} index={index} {...service} />
        ))}
      </div>
    </>
  );
};

export default SectionWrapper(About, "about");
